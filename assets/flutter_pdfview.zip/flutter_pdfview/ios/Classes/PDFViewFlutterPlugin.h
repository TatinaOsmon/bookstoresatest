#import <Flutter/Flutter.h>

@interface FLTPDFViewFlutterPlugin : NSObject<FlutterPlugin>
@end
